const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { authMiddleware, adminOnly } = require('../middleware/auth');

// Get all books (both admin and student)
router.get('/', authMiddleware, async (req, res) => {
  try {
    const [books] = await db.query('SELECT * FROM books ORDER BY title ASC');
    res.json(books);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get single book
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM books WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Book not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Add book (admin only)
router.post('/', authMiddleware, adminOnly, async (req, res) => {
  const { title, author, isbn, category, total_copies } = req.body;
  try {
    await db.query(
      'INSERT INTO books (title, author, isbn, category, total_copies, available_copies) VALUES (?, ?, ?, ?, ?, ?)',
      [title, author, isbn, category, total_copies, total_copies]
    );
    res.status(201).json({ message: 'Book added successfully' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ message: 'ISBN already exists' });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Update book (admin only)
router.put('/:id', authMiddleware, adminOnly, async (req, res) => {
  const { title, author, isbn, category, total_copies } = req.body;
  try {
    const [existing] = await db.query('SELECT * FROM books WHERE id = ?', [req.params.id]);
    if (existing.length === 0) return res.status(404).json({ message: 'Book not found' });

    const book = existing[0];
    const diff = total_copies - book.total_copies;
    const newAvailable = Math.max(0, book.available_copies + diff);

    await db.query(
      'UPDATE books SET title=?, author=?, isbn=?, category=?, total_copies=?, available_copies=? WHERE id=?',
      [title, author, isbn, category, total_copies, newAvailable, req.params.id]
    );
    res.json({ message: 'Book updated successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Delete book (admin only)
router.delete('/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    const [issued] = await db.query(
      "SELECT id FROM issued_books WHERE book_id = ? AND status = 'issued'",
      [req.params.id]
    );
    if (issued.length > 0) {
      return res.status(400).json({ message: 'Cannot delete book — copies are currently issued' });
    }
    await db.query('DELETE FROM books WHERE id = ?', [req.params.id]);
    res.json({ message: 'Book deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
