const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { authMiddleware, adminOnly } = require('../middleware/auth');

const FINE_PER_DAY = 2; // Rs. 2 per day after due date

// Calculate fine
function calculateFine(dueDate, returnDate) {
  const due = new Date(dueDate);
  const returned = new Date(returnDate);
  const diffTime = returned - due;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays > 0 ? diffDays * FINE_PER_DAY : 0;
}

// Issue book (admin only)
router.post('/issue', authMiddleware, adminOnly, async (req, res) => {
  const { book_id, student_id, due_days = 14 } = req.body;
  try {
    // Check book availability
    const [books] = await db.query('SELECT * FROM books WHERE id = ?', [book_id]);
    if (books.length === 0) return res.status(404).json({ message: 'Book not found' });
    if (books[0].available_copies <= 0) return res.status(400).json({ message: 'No copies available' });

    // Check student exists
    const [students] = await db.query('SELECT id FROM students WHERE id = ?', [student_id]);
    if (students.length === 0) return res.status(404).json({ message: 'Student not found' });

    // Check if student already has this book
    const [alreadyIssued] = await db.query(
      "SELECT id FROM issued_books WHERE book_id=? AND student_id=? AND status='issued'",
      [book_id, student_id]
    );
    if (alreadyIssued.length > 0) {
      return res.status(400).json({ message: 'Student already has this book issued' });
    }

    const issue_date = new Date().toISOString().split('T')[0];
    const due_date = new Date(Date.now() + due_days * 86400000).toISOString().split('T')[0];

    await db.query(
      'INSERT INTO issued_books (book_id, student_id, issue_date, due_date) VALUES (?, ?, ?, ?)',
      [book_id, student_id, issue_date, due_date]
    );

    await db.query(
      'UPDATE books SET available_copies = available_copies - 1 WHERE id = ?',
      [book_id]
    );

    res.status(201).json({ message: 'Book issued successfully', issue_date, due_date });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Return book (admin only)
router.post('/return/:issue_id', authMiddleware, adminOnly, async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT * FROM issued_books WHERE id = ? AND status = 'issued'",
      [req.params.issue_id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Issued record not found' });

    const record = rows[0];
    const return_date = new Date().toISOString().split('T')[0];
    const fine = calculateFine(record.due_date, return_date);

    await db.query(
      "UPDATE issued_books SET return_date=?, fine_amount=?, status='returned' WHERE id=?",
      [return_date, fine, req.params.issue_id]
    );

    await db.query(
      'UPDATE books SET available_copies = available_copies + 1 WHERE id = ?',
      [record.book_id]
    );

    res.json({ message: 'Book returned successfully', fine_amount: fine, return_date });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get all issued books (admin)
router.get('/all', authMiddleware, adminOnly, async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT ib.*, b.title AS book_title, b.author, s.name AS student_name, s.roll_number
      FROM issued_books ib
      JOIN books b ON ib.book_id = b.id
      JOIN students s ON ib.student_id = s.id
      ORDER BY ib.created_at DESC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get student's issued books
router.get('/my', authMiddleware, async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT ib.*, b.title AS book_title, b.author, b.isbn
      FROM issued_books ib
      JOIN books b ON ib.book_id = b.id
      WHERE ib.student_id = ?
      ORDER BY ib.created_at DESC
    `, [req.user.id]);

    // Add live fine for currently issued books
    const today = new Date().toISOString().split('T')[0];
    const enriched = rows.map(row => ({
      ...row,
      current_fine: row.status === 'issued' ? calculateFine(row.due_date, today) : row.fine_amount
    }));

    res.json(enriched);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get all students (admin)
router.get('/students', authMiddleware, adminOnly, async (req, res) => {
  try {
    const [rows] = await db.query('SELECT id, name, email, roll_number, phone, created_at FROM students ORDER BY name ASC');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
