-- Run this SQL in Railway MySQL to set up the database

CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

-- Admin table
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Students table
CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  roll_number VARCHAR(50) UNIQUE NOT NULL,
  phone VARCHAR(15),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Books table
CREATE TABLE IF NOT EXISTS books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  author VARCHAR(100) NOT NULL,
  isbn VARCHAR(50) UNIQUE NOT NULL,
  category VARCHAR(100),
  total_copies INT DEFAULT 1,
  available_copies INT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Issued books table
CREATE TABLE IF NOT EXISTS issued_books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  book_id INT NOT NULL,
  student_id INT NOT NULL,
  issue_date DATE NOT NULL,
  due_date DATE NOT NULL,
  return_date DATE DEFAULT NULL,
  fine_amount DECIMAL(10,2) DEFAULT 0.00,
  status ENUM('issued', 'returned') DEFAULT 'issued',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (book_id) REFERENCES books(id),
  FOREIGN KEY (student_id) REFERENCES students(id)
);

-- Seed default admin (password: admin123)
INSERT IGNORE INTO admins (name, email, password)
VALUES ('Admin', 'admin@library.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Seed some books
INSERT IGNORE INTO books (title, author, isbn, category, total_copies, available_copies) VALUES
('Introduction to Algorithms', 'Thomas H. Cormen', 'ISBN-001', 'Computer Science', 3, 3),
('Clean Code', 'Robert C. Martin', 'ISBN-002', 'Programming', 2, 2),
('The Pragmatic Programmer', 'Andrew Hunt', 'ISBN-003', 'Programming', 2, 2),
('Database System Concepts', 'Abraham Silberschatz', 'ISBN-004', 'Database', 3, 3),
('Operating System Concepts', 'Abraham Silberschatz', 'ISBN-005', 'Operating Systems', 4, 4),
('Computer Networks', 'Andrew Tanenbaum', 'ISBN-006', 'Networks', 3, 3),
('Let Us C', 'Yashavant Kanetkar', 'ISBN-007', 'Programming', 5, 5),
('Head First Java', 'Kathy Sierra', 'ISBN-008', 'Java', 4, 4);
