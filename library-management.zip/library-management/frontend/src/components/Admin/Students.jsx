import { useEffect, useState } from 'react';
import API from '../../utils/api';

export default function Students() {
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    API.get('/issues/students').then(r => setStudents(r.data));
  }, []);

  const filtered = students.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.roll_number.toLowerCase().includes(search.toLowerCase()) ||
    s.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="page-header">
        <h1>Registered Students</h1>
        <span style={{ color: '#64748b', fontSize: '14px' }}>{students.length} total</span>
      </div>
      <div className="card">
        <input className="search-bar" placeholder="Search by name, roll number, email..."
          value={search} onChange={e => setSearch(e.target.value)} style={{ marginBottom: '16px' }} />
        <div className="table-wrapper">
          <table>
            <thead>
              <tr><th>#</th><th>Name</th><th>Roll Number</th><th>Email</th><th>Phone</th><th>Joined</th></tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', color: '#94a3b8', padding: '24px' }}>No students found</td></tr>
              ) : filtered.map((s, idx) => (
                <tr key={s.id}>
                  <td style={{ color: '#94a3b8' }}>{idx + 1}</td>
                  <td><strong>{s.name}</strong></td>
                  <td><span className="badge badge-blue">{s.roll_number}</span></td>
                  <td>{s.email}</td>
                  <td>{s.phone || '—'}</td>
                  <td style={{ fontSize: '12px', color: '#94a3b8' }}>{new Date(s.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
