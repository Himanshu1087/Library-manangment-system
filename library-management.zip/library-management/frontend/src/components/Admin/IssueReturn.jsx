import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import API from '../../utils/api';

export default function IssueReturn() {
  const [tab, setTab] = useState('issue');
  const [books, setBooks] = useState([]);
  const [students, setStudents] = useState([]);
  const [issues, setIssues] = useState([]);
  const [form, setForm] = useState({ book_id: '', student_id: '', due_days: 14 });
  const [search, setSearch] = useState('');

  const load = async () => {
    const [b, s, i] = await Promise.all([API.get('/books'), API.get('/issues/students'), API.get('/issues/all')]);
    setBooks(b.data);
    setStudents(s.data);
    setIssues(i.data);
  };
  useEffect(() => { load(); }, []);

  const handleIssue = async (e) => {
    e.preventDefault();
    try {
      const { data } = await API.post('/issues/issue', form);
      toast.success(`Book issued! Due: ${data.due_date}`);
      setForm({ book_id: '', student_id: '', due_days: 14 });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error');
    }
  };

  const handleReturn = async (issue) => {
    if (!confirm(`Return "${issue.book_title}" from ${issue.student_name}?`)) return;
    try {
      const { data } = await API.post(`/issues/return/${issue.id}`);
      toast.success(`Returned! Fine: ₹${data.fine_amount}`);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error');
    }
  };

  const activeIssues = issues.filter(i => i.status === 'issued');
  const today = new Date().toISOString().split('T')[0];
  const filteredIssues = activeIssues.filter(i =>
    i.book_title?.toLowerCase().includes(search.toLowerCase()) ||
    i.student_name?.toLowerCase().includes(search.toLowerCase()) ||
    i.roll_number?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="page-header"><h1>Issue / Return Books</h1></div>

      <div className="login-tabs" style={{ marginBottom: '24px', maxWidth: '300px', borderRadius: '10px' }}>
        <button className={`login-tab ${tab === 'issue' ? 'active' : ''}`} onClick={() => setTab('issue')}>Issue Book</button>
        <button className={`login-tab ${tab === 'return' ? 'active' : ''}`} onClick={() => setTab('return')}>Return Book</button>
      </div>

      {tab === 'issue' ? (
        <div className="card" style={{ maxWidth: '520px' }}>
          <div className="card-title">Issue a Book to Student</div>
          <form onSubmit={handleIssue}>
            <div className="form-group">
              <label>Select Book</label>
              <select value={form.book_id} onChange={e => setForm({ ...form, book_id: e.target.value })} required>
                <option value="">-- Select Book --</option>
                {books.filter(b => b.available_copies > 0).map(b => (
                  <option key={b.id} value={b.id}>{b.title} — {b.author} ({b.available_copies} available)</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Select Student</label>
              <select value={form.student_id} onChange={e => setForm({ ...form, student_id: e.target.value })} required>
                <option value="">-- Select Student --</option>
                {students.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.roll_number})</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Due in (days)</label>
              <input type="number" min="1" max="90" value={form.due_days}
                onChange={e => setForm({ ...form, due_days: +e.target.value })} />
            </div>
            <button className="btn btn-primary" type="submit">Issue Book</button>
          </form>
        </div>
      ) : (
        <div className="card">
          <div className="card-title">Currently Issued Books ({activeIssues.length})</div>
          <input className="search-bar" placeholder="Search by book, student, roll no..."
            value={search} onChange={e => setSearch(e.target.value)} style={{ marginBottom: '16px' }} />
          <div className="table-wrapper">
            <table>
              <thead>
                <tr><th>Book</th><th>Student</th><th>Issue Date</th><th>Due Date</th><th>Fine (Live)</th><th>Action</th></tr>
              </thead>
              <tbody>
                {filteredIssues.length === 0 ? (
                  <tr><td colSpan={6} style={{ textAlign: 'center', color: '#94a3b8', padding: '24px' }}>No books currently issued</td></tr>
                ) : filteredIssues.map(i => {
                  const overdue = i.due_date < today;
                  const diffDays = Math.ceil((new Date(today) - new Date(i.due_date)) / 86400000);
                  const fine = overdue ? diffDays * 2 : 0;
                  return (
                    <tr key={i.id}>
                      <td><strong>{i.book_title}</strong></td>
                      <td>{i.student_name}<br /><span style={{ fontSize: '12px', color: '#94a3b8' }}>{i.roll_number}</span></td>
                      <td>{i.issue_date}</td>
                      <td style={{ color: overdue ? '#dc2626' : 'inherit', fontWeight: overdue ? 600 : 400 }}>
                        {i.due_date} {overdue && `(${diffDays}d late)`}
                      </td>
                      <td>{fine > 0 ? <span className="badge badge-red">₹{fine}</span> : <span className="badge badge-green">₹0</span>}</td>
                      <td><button className="btn btn-success btn-sm" onClick={() => handleReturn(i)}>Return</button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
