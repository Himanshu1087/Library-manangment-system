import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import API from '../../utils/api';

const empty = { title: '', author: '', isbn: '', category: '', total_copies: 1 };

export default function AdminBooks() {
  const [books, setBooks] = useState([]);
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);

  const load = async () => {
    const { data } = await API.get('/books');
    setBooks(data);
  };
  useEffect(() => { load(); }, []);

  const filtered = books.filter(b =>
    b.title.toLowerCase().includes(search.toLowerCase()) ||
    b.author.toLowerCase().includes(search.toLowerCase()) ||
    b.category?.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => { setEditing(null); setForm(empty); setModal(true); };
  const openEdit = (book) => { setEditing(book); setForm({ title: book.title, author: book.author, isbn: book.isbn, category: book.category, total_copies: book.total_copies }); setModal(true); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editing) {
        await API.put(`/books/${editing.id}`, form);
        toast.success('Book updated!');
      } else {
        await API.post('/books', form);
        toast.success('Book added!');
      }
      setModal(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error');
    }
  };

  const handleDelete = async (book) => {
    if (!confirm(`Delete "${book.title}"?`)) return;
    try {
      await API.delete(`/books/${book.id}`);
      toast.success('Book deleted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error');
    }
  };

  return (
    <div>
      <div className="page-header">
        <h1>Manage Books</h1>
        <button className="btn btn-primary" onClick={openAdd}>+ Add Book</button>
      </div>

      <div className="card">
        <input className="search-bar" placeholder="Search by title, author, category..."
          value={search} onChange={e => setSearch(e.target.value)} style={{ marginBottom: '16px' }} />
        <div className="table-wrapper">
          <table>
            <thead>
              <tr><th>Title</th><th>Author</th><th>Category</th><th>ISBN</th><th>Total</th><th>Available</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {filtered.map(b => (
                <tr key={b.id}>
                  <td><strong>{b.title}</strong></td>
                  <td>{b.author}</td>
                  <td><span className="badge badge-blue">{b.category}</span></td>
                  <td style={{ fontSize: '12px', color: '#94a3b8' }}>{b.isbn}</td>
                  <td>{b.total_copies}</td>
                  <td>
                    <span className={`badge ${b.available_copies === 0 ? 'badge-red' : 'badge-green'}`}>
                      {b.available_copies}
                    </span>
                  </td>
                  <td style={{ display: 'flex', gap: '6px' }}>
                    <button className="btn btn-warning btn-sm" onClick={() => openEdit(b)}>Edit</button>
                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(b)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <h3>{editing ? 'Edit Book' : 'Add New Book'}</h3>
              <button className="modal-close" onClick={() => setModal(false)}>✕</button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group"><label>Title</label>
                <input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required />
              </div>
              <div className="form-group"><label>Author</label>
                <input value={form.author} onChange={e => setForm({ ...form, author: e.target.value })} required />
              </div>
              <div className="form-row">
                <div className="form-group"><label>ISBN</label>
                  <input value={form.isbn} onChange={e => setForm({ ...form, isbn: e.target.value })} required />
                </div>
                <div className="form-group"><label>Category</label>
                  <input value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} />
                </div>
              </div>
              <div className="form-group"><label>Total Copies</label>
                <input type="number" min="1" value={form.total_copies} onChange={e => setForm({ ...form, total_copies: +e.target.value })} required />
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">{editing ? 'Update' : 'Add Book'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
