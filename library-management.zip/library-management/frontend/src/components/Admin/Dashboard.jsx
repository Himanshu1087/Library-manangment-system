import { useEffect, useState } from 'react';
import API from '../../utils/api';

export default function AdminDashboard() {
  const [stats, setStats] = useState({ books: 0, students: 0, issued: 0, overdue: 0 });
  const [recentIssues, setRecentIssues] = useState([]);

  useEffect(() => {
    const load = async () => {
      const [booksRes, issuesRes, studentsRes] = await Promise.all([
        API.get('/books'),
        API.get('/issues/all'),
        API.get('/issues/students'),
      ]);
      const today = new Date().toISOString().split('T')[0];
      const issued = issuesRes.data.filter(i => i.status === 'issued');
      const overdue = issued.filter(i => i.due_date < today);
      setStats({
        books: booksRes.data.length,
        students: studentsRes.data.length,
        issued: issued.length,
        overdue: overdue.length,
      });
      setRecentIssues(issuesRes.data.slice(0, 8));
    };
    load();
  }, []);

  return (
    <div>
      <div className="page-header">
        <h1>Dashboard</h1>
      </div>

      <div className="stats-grid">
        <div className="stat-card blue">
          <div className="stat-value">{stats.books}</div>
          <div className="stat-label">Total Books</div>
        </div>
        <div className="stat-card green">
          <div className="stat-value">{stats.students}</div>
          <div className="stat-label">Registered Students</div>
        </div>
        <div className="stat-card orange">
          <div className="stat-value">{stats.issued}</div>
          <div className="stat-label">Books Issued</div>
        </div>
        <div className="stat-card red">
          <div className="stat-value">{stats.overdue}</div>
          <div className="stat-label">Overdue</div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Recent Transactions</div>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Book</th>
                <th>Student</th>
                <th>Issue Date</th>
                <th>Due Date</th>
                <th>Status</th>
                <th>Fine</th>
              </tr>
            </thead>
            <tbody>
              {recentIssues.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', color: '#94a3b8', padding: '24px' }}>No transactions yet</td></tr>
              ) : recentIssues.map(i => {
                const today = new Date().toISOString().split('T')[0];
                const isOverdue = i.status === 'issued' && i.due_date < today;
                return (
                  <tr key={i.id}>
                    <td><strong>{i.book_title}</strong></td>
                    <td>{i.student_name}<br /><span style={{ fontSize: '12px', color: '#94a3b8' }}>{i.roll_number}</span></td>
                    <td>{i.issue_date}</td>
                    <td style={{ color: isOverdue ? '#dc2626' : 'inherit' }}>{i.due_date}</td>
                    <td>
                      <span className={`badge ${i.status === 'issued' ? (isOverdue ? 'badge-red' : 'badge-blue') : 'badge-green'}`}>
                        {i.status === 'issued' ? (isOverdue ? 'Overdue' : 'Issued') : 'Returned'}
                      </span>
                    </td>
                    <td>{i.fine_amount > 0 ? <span className="badge badge-red">₹{i.fine_amount}</span> : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
