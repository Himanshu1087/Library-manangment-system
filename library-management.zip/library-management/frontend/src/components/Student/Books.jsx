import { useEffect, useState } from 'react';
import API from '../../utils/api';

export default function StudentBooks() {
  const [books, setBooks] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');

  useEffect(() => {
    API.get('/books').then(r => setBooks(r.data));
  }, []);

  const categories = [...new Set(books.map(b => b.category).filter(Boolean))];

  const filtered = books.filter(b => {
    const matchSearch = b.title.toLowerCase().includes(search.toLowerCase()) ||
      b.author.toLowerCase().includes(search.toLowerCase());
    const matchCat = !category || b.category === category;
    return matchSearch && matchCat;
  });

  return (
    <div>
      <div className="page-header"><h1>Browse Books</h1></div>

      <div style={{ display: 'flex', gap: '12px', marginBottom: '20px', flexWrap: 'wrap' }}>
        <input className="search-bar" placeholder="Search by title or author..."
          value={search} onChange={e => setSearch(e.target.value)} />
        <select style={{ padding: '9px 12px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px', fontFamily: 'Inter, sans-serif' }}
          value={category} onChange={e => setCategory(e.target.value)}>
          <option value="">All Categories</option>
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <div className="card">
        <div className="table-wrapper">
          <table>
            <thead>
              <tr><th>Title</th><th>Author</th><th>Category</th><th>Availability</th></tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={4} style={{ textAlign: 'center', color: '#94a3b8', padding: '32px' }}>No books found</td></tr>
              ) : filtered.map(b => (
                <tr key={b.id}>
                  <td><strong>{b.title}</strong><br /><span style={{ fontSize: '12px', color: '#94a3b8' }}>ISBN: {b.isbn}</span></td>
                  <td>{b.author}</td>
                  <td><span className="badge badge-blue">{b.category}</span></td>
                  <td>
                    {b.available_copies > 0
                      ? <span className="badge badge-green">{b.available_copies} / {b.total_copies} Available</span>
                      : <span className="badge badge-red">Not Available</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
