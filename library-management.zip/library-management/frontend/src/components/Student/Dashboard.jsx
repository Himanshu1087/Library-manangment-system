import { useEffect, useState } from 'react';
import API from '../../utils/api';
import { useAuth } from '../../context/AuthContext';

export default function StudentDashboard() {
  const { user } = useAuth();
  const [myBooks, setMyBooks] = useState([]);

  useEffect(() => {
    API.get('/issues/my').then(r => setMyBooks(r.data));
  }, []);

  const issued = myBooks.filter(b => b.status === 'issued');
  const returned = myBooks.filter(b => b.status === 'returned');
  const totalFine = issued.reduce((sum, b) => sum + (b.current_fine || 0), 0);
  const today = new Date().toISOString().split('T')[0];

  return (
    <div>
      <div className="page-header">
        <h1>Welcome, {user?.name} 👋</h1>
      </div>

      <div className="stats-grid">
        <div className="stat-card blue"><div className="stat-value">{issued.length}</div><div className="stat-label">Books Issued</div></div>
        <div className="stat-card green"><div className="stat-value">{returned.length}</div><div className="stat-label">Books Returned</div></div>
        <div className="stat-card red"><div className="stat-value">₹{totalFine}</div><div className="stat-label">Total Fine Due</div></div>
      </div>

      {issued.length > 0 && (
        <div className="card">
          <div className="card-title">Currently Issued Books</div>
          <div className="table-wrapper">
            <table>
              <thead>
                <tr><th>Book</th><th>Author</th><th>Issue Date</th><th>Due Date</th><th>Fine</th></tr>
              </thead>
              <tbody>
                {issued.map(b => {
                  const overdue = b.due_date < today;
                  return (
                    <tr key={b.id}>
                      <td><strong>{b.book_title}</strong></td>
                      <td>{b.author}</td>
                      <td>{b.issue_date}</td>
                      <td style={{ color: overdue ? '#dc2626' : 'inherit', fontWeight: overdue ? 600 : 400 }}>
                        {b.due_date} {overdue && '⚠️'}
                      </td>
                      <td>
                        {b.current_fine > 0
                          ? <span className="badge badge-red">₹{b.current_fine}</span>
                          : <span className="badge badge-green">No Fine</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {issued.length === 0 && (
        <div className="card">
          <div className="empty-state">
            <h3>No books currently issued</h3>
            <p>Browse the library to find books you want to read!</p>
          </div>
        </div>
      )}
    </div>
  );
}
