import { useEffect, useState } from 'react';
import API from '../../utils/api';

export default function MyBooks() {
  const [books, setBooks] = useState([]);
  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    API.get('/issues/my').then(r => setBooks(r.data));
  }, []);

  const issued = books.filter(b => b.status === 'issued');
  const returned = books.filter(b => b.status === 'returned');

  return (
    <div>
      <div className="page-header"><h1>My Books</h1></div>

      <div className="card">
        <div className="card-title">Currently Issued ({issued.length})</div>
        {issued.length === 0 ? (
          <div className="empty-state"><h3>No books currently issued</h3></div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead><tr><th>Book</th><th>Author</th><th>Issue Date</th><th>Due Date</th><th>Status</th><th>Fine</th></tr></thead>
              <tbody>
                {issued.map(b => {
                  const overdue = b.due_date < today;
                  return (
                    <tr key={b.id}>
                      <td><strong>{b.book_title}</strong></td>
                      <td>{b.author}</td>
                      <td>{b.issue_date}</td>
                      <td style={{ color: overdue ? '#dc2626' : 'inherit', fontWeight: overdue ? 600 : 400 }}>{b.due_date}</td>
                      <td><span className={`badge ${overdue ? 'badge-red' : 'badge-blue'}`}>{overdue ? 'Overdue' : 'On Time'}</span></td>
                      <td>{b.current_fine > 0 ? <span className="badge badge-red">₹{b.current_fine}</span> : '₹0'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="card">
        <div className="card-title">Return History ({returned.length})</div>
        {returned.length === 0 ? (
          <div className="empty-state"><h3>No return history yet</h3></div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead><tr><th>Book</th><th>Issue Date</th><th>Return Date</th><th>Fine Paid</th></tr></thead>
              <tbody>
                {returned.map(b => (
                  <tr key={b.id}>
                    <td><strong>{b.book_title}</strong></td>
                    <td>{b.issue_date}</td>
                    <td>{b.return_date}</td>
                    <td>{b.fine_amount > 0 ? <span className="badge badge-orange">₹{b.fine_amount}</span> : <span className="badge badge-green">₹0</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
