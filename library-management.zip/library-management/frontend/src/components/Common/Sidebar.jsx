import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const adminLinks = [
  { to: '/admin/dashboard', label: '📊 Dashboard' },
  { to: '/admin/books', label: '📚 Manage Books' },
  { to: '/admin/issue-return', label: '🔄 Issue / Return' },
  { to: '/admin/students', label: '👥 Students' },
];

const studentLinks = [
  { to: '/student/dashboard', label: '🏠 Dashboard' },
  { to: '/student/books', label: '📚 Browse Books' },
  { to: '/student/my-books', label: '📖 My Books' },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const links = user?.role === 'admin' ? adminLinks : studentLinks;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="sidebar">
      <div className="sidebar-logo">
        📚 LibraryMS
        <span>{user?.role === 'admin' ? 'Admin Panel' : 'Student Portal'}</span>
      </div>
      <nav className="sidebar-nav">
        {links.map(link => (
          <NavLink key={link.to} to={link.to} className={({ isActive }) => isActive ? 'active' : ''}>
            {link.label}
          </NavLink>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="sidebar-user">
          <strong>{user?.name}</strong>
          {user?.email}
        </div>
        <button className="btn btn-outline" style={{ width: '100%', justifyContent: 'center', color: 'rgba(255,255,255,0.7)', borderColor: 'rgba(255,255,255,0.2)' }}
          onClick={handleLogout}>
          🚪 Logout
        </button>
      </div>
    </div>
  );
}
