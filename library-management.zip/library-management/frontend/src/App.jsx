import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './index.css';

import { AuthProvider, useAuth } from './context/AuthContext';
import Sidebar from './components/Common/Sidebar';
import Login from './pages/Login';

import AdminDashboard from './components/Admin/Dashboard';
import AdminBooks from './components/Admin/Books';
import IssueReturn from './components/Admin/IssueReturn';
import Students from './components/Admin/Students';

import StudentDashboard from './components/Student/Dashboard';
import StudentBooks from './components/Student/Books';
import MyBooks from './components/Student/MyBooks';

function ProtectedLayout({ children, role }) {
  const { user, loading } = useAuth();
  if (loading) return <div style={{ padding: '40px', textAlign: 'center' }}>Loading...</div>;
  if (!user) return <Navigate to="/login" />;
  if (role && user.role !== role) return <Navigate to="/login" />;
  return (
    <div className="app-layout">
      <Sidebar />
      <div className="layout-with-sidebar" style={{ flex: 1 }}>
        <div className="main-content">{children}</div>
      </div>
    </div>
  );
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to={user.role === 'admin' ? '/admin/dashboard' : '/student/dashboard'} /> : <Login />} />

      <Route path="/admin/dashboard" element={<ProtectedLayout role="admin"><AdminDashboard /></ProtectedLayout>} />
      <Route path="/admin/books" element={<ProtectedLayout role="admin"><AdminBooks /></ProtectedLayout>} />
      <Route path="/admin/issue-return" element={<ProtectedLayout role="admin"><IssueReturn /></ProtectedLayout>} />
      <Route path="/admin/students" element={<ProtectedLayout role="admin"><Students /></ProtectedLayout>} />

      <Route path="/student/dashboard" element={<ProtectedLayout role="student"><StudentDashboard /></ProtectedLayout>} />
      <Route path="/student/books" element={<ProtectedLayout role="student"><StudentBooks /></ProtectedLayout>} />
      <Route path="/student/my-books" element={<ProtectedLayout role="student"><MyBooks /></ProtectedLayout>} />

      <Route path="*" element={<Navigate to="/login" />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
        <ToastContainer position="top-right" autoClose={3000} />
      </BrowserRouter>
    </AuthProvider>
  );
}
