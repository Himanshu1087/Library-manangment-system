import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import API from '../../utils/api';
import { useAuth } from '../../context/AuthContext';

export default function Login() {
  const [tab, setTab] = useState('student'); // 'student' | 'admin' | 'register'
  const [form, setForm] = useState({ name: '', email: '', password: '', roll_number: '', phone: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const endpoint = tab === 'admin' ? '/auth/admin/login' : '/auth/student/login';
      const { data } = await API.post(endpoint, { email: form.email, password: form.password });
      login(data.user, data.token);
      toast.success(`Welcome, ${data.user.name}!`);
      navigate(data.user.role === 'admin' ? '/admin/dashboard' : '/student/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await API.post('/auth/student/register', form);
      toast.success('Registered! Please login.');
      setTab('student');
      setForm({ ...form, name: '', roll_number: '', phone: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-box">
        <div className="login-logo">
          <h1>📚 LibraryMS</h1>
          <p>Library Management System</p>
        </div>

        <div className="login-tabs">
          <button className={`login-tab ${tab === 'student' ? 'active' : ''}`} onClick={() => setTab('student')}>Student Login</button>
          <button className={`login-tab ${tab === 'admin' ? 'active' : ''}`} onClick={() => setTab('admin')}>Admin Login</button>
          <button className={`login-tab ${tab === 'register' ? 'active' : ''}`} onClick={() => setTab('register')}>Register</button>
        </div>

        {tab !== 'register' ? (
          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label>Email</label>
              <input name="email" type="email" placeholder={tab === 'admin' ? 'admin@library.com' : 'your@email.com'}
                value={form.email} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input name="password" type="password" placeholder="Enter password"
                value={form.password} onChange={handleChange} required />
            </div>
            {tab === 'admin' && (
              <p style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '16px' }}>
                Default: admin@library.com / admin123
              </p>
            )}
            <button className="btn btn-primary" style={{ width: '100%', padding: '11px', justifyContent: 'center' }}
              type="submit" disabled={loading}>
              {loading ? 'Logging in...' : `Login as ${tab === 'admin' ? 'Admin' : 'Student'}`}
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegister}>
            <div className="form-group">
              <label>Full Name</label>
              <input name="name" placeholder="Himanshu Solanki" value={form.name} onChange={handleChange} required />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label>Roll Number</label>
                <input name="roll_number" placeholder="0901CS211001" value={form.roll_number} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label>Phone</label>
                <input name="phone" placeholder="9876543210" value={form.phone} onChange={handleChange} />
              </div>
            </div>
            <div className="form-group">
              <label>Email</label>
              <input name="email" type="email" placeholder="your@email.com" value={form.email} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input name="password" type="password" placeholder="Create password" value={form.password} onChange={handleChange} required />
            </div>
            <button className="btn btn-success" style={{ width: '100%', padding: '11px', justifyContent: 'center' }}
              type="submit" disabled={loading}>
              {loading ? 'Registering...' : 'Create Account'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
